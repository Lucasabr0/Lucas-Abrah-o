document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('loginModal');
    const btn = document.getElementById('loginBtn');
    const span = document.getElementsByClassName('close')[0];
    const loginForm = document.getElementById('loginForm');

    // Abrir modal
    btn.onclick = function() {
        modal.style.display = "block";
    }

    // Fechar modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // Fechar modal clicando fora
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Manipular envio do formulário
    loginForm.onsubmit = async function(e) {
        e.preventDefault();
        
        const formData = new FormData(loginForm);
        try {
            const response = await fetch('backend/api/login.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                window.location.href = 'dashboard.html';
            } else {
                alert('Erro no login: ' + data.message);
            }
        } catch (error) {
            console.error('Erro:', error);
            alert('Erro ao conectar com o servidor');
        }
    }
});
